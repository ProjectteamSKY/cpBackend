from fastapi import APIRouter, Query
from fastapi.middleware.cors import CORSMiddleware
import mysql.connector
from typing import Optional
import os

router = APIRouter()


# package install
DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "citizen_erp"),
    "password": os.getenv("DB_PASSWORD", "Citizen123"),
    "database": os.getenv("DB_NAME", "cp_erp_db"),
}

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)


@router.get("/customers/search")
def search_customers(
    q: str = Query(default="", min_length=0),
    type: str = Query(default="credit")
):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    like_q = f"%{q}%"

    if type == "general":
        cursor.execute(
            """
            SELECT DISTINCT customer_code, customer_name, customer_mobile_no as mobile_no
            FROM jobcard_master
            WHERE (customer_name LIKE %s OR customer_mobile_no LIKE %s)
            AND customer_type IN ('General', 'WalkIn')
            ORDER BY customer_name
            LIMIT 20
            """,
            (like_q, like_q),
        )
    else:
        cursor.execute(
            """
            SELECT DISTINCT customer_code, customer_name, customer_mobile_no as mobile_no
            FROM jobcard_master
            WHERE customer_name LIKE %s
            AND customer_type = 'Credit'
            ORDER BY customer_name
            LIMIT 20
            """,
            (like_q,),
        )

    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return rows

@router.get("/customers/{customer_code}")
def get_customer(customer_code: str):
    """
    Get full customer details by customer_code.
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        """
        SELECT customer_code, customer_name, customer_type,
               customer_addr1, customer_addr2, customer_city,
               customer_state_code, customer_state, customer_pin_code,
               gst_no, mobile_no, customer_email_id
        FROM customer_master
        WHERE customer_code = %s
        LIMIT 1
        """,
        (customer_code,),
    )
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if not row:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Customer not found")
    return row


@router.get("/customers/{customer_code}/history")
def get_customer_history(customer_code: str):
    """
    Get job card history for a customer.
    Returns list of recent job cards.
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        """
        SELECT jm.jobcard_no, jm.jobcard_date, jm.approximate_amount,
               jm.advance_amount, jm.delivery_txt, jm.remarks_txt,
               jm.customer_type
        FROM jobcard_master jm
        WHERE jm.credit_customer_code = %s
           OR (jm.customer_mobile_no = (
                   SELECT mobile_no FROM customer_master WHERE customer_code = %s LIMIT 1
               ) AND jm.customer_type != 'Credit')
        ORDER BY jm.jobcard_date DESC, jm.jobcard_no DESC
        LIMIT 20
        """,
        (customer_code, customer_code),
    )
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    # Convert dates to string for JSON serialisation
    for r in rows:
        if r.get("jobcard_date"):
            r["jobcard_date"] = str(r["jobcard_date"])
    return rows
